from setuptools import setup

setup(
	name="paquetecalculos",#se puede poner cualquier nombre
	version="1.0",
	description="paquete de redondeo y potencia",
	author="MoncadaVelásquez",
	author_email="cursos@gmail.com",
	url="gitmoncada.com",
	packages=["calculos","calculos.redondeo_potencia"]
    )