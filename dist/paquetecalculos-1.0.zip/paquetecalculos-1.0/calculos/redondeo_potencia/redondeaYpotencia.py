def potencia(base,exponente):
    print("El resultado de la exponenciación es: ",base**exponente)

def redondear(numero):
	print("El redondeo del número ",numero, "es: ",round(numero))